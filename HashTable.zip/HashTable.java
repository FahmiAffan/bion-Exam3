/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.main;

/**
 *
 * @author fahmi
 */
// HashTable.java
public class HashTable {
    private Node[] table;
    private int size;

    public HashTable(int size) {
        this.size = size;
        table = new Node[size];
    }

    private int hash(String key) {
        return Math.abs(key.hashCode()) % size;
    }

    public void insert(String name) {
        int index = hash(name);
        Node newNode = new Node(name);

        if (table[index] == null) {
            table[index] = newNode;
        } else {
            Node current = table[index];
            while (current.next != null) current = current.next;
            current.next = newNode;
        }
    }

    public void display() {
        System.out.println("Hash Table (Chaining):");
        for (int i = 0; i < size; i++) {
            System.out.print(i + " → ");
            Node current = table[i];
            while (current != null) {
                System.out.print(current.name);
                if (current.next != null) System.out.print(" → ");
                current = current.next;
            }
            System.out.println();
        }
    }
}

