package com.mycompany.main;

// BinarySearchTree.java
// Main.java
public class Main {
    public static void main(String[] args) {
        HashTable ht = new HashTable(10);

        String[] names = {
            "Andi", "Ingrit", "Dora", "Chris", "Della",
            "Jeremy", "Jessica", "Bella", "Emma", "Blake"
        };

        for (String name : names) {
            ht.insert(name);
        }

        ht.display();
    }
}

