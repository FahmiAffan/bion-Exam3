// Employee.java
public abstract class Employee {
    private String id;
    private String name;

    public Employee(String id, String name) {
        this.id   = id;
        this.name = name;
    }

    // Encapsulation: akses lewat getter/setter
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    // Polymorphism: tiap subclass implementasi berbeda
    public abstract double calculateSalary();

    @Override
    public String toString() {
        return String.format("ID: %s, Name: %s, Salary: %.2f",
                             id, name, calculateSalary());
    }
}
