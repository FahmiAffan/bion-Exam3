public class Main {
    public static void main(String[] args) {
        FullTimeEmployee ft = new FullTimeEmployee("FT001", "Andi", 5_000_000, 0);
        PartTimeEmployee pt = new PartTimeEmployee("PT001", "Budi", 50_000, 80);

        System.out.println("Gaji Pegawai Tetap " + ft.getName() + ": Rp" + ft.calculateSalary());
        System.out.println("Gaji Pegawai Paruh Waktu " + pt.getName() + ": Rp" + pt.calculateSalary());
    }
}
