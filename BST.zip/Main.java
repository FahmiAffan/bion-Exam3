package com.mycompany.main;

// BinarySearchTree.java
public class Main {

    private Node root;

    public Main() {
        root = null;
    }

    // Public insert
    public void insert(int value) {
        root = insertRec(root, value);
    }

    // Rekursif helper untuk insert
    private Node insertRec(Node node, int value) {
        if (node == null) {
            return new Node(value);
        }
        if (value < node.data) {
            node.left = insertRec(node.left, value);
        } else {
            // duplikat atau lebih besar → ke kanan
            node.right = insertRec(node.right, value);
        }
        return node;
    }

    // Inorder traversal (sorted)
    public void inorder() {
        inorderRec(root);
        System.out.println();
    }

    private void inorderRec(Node node) {
        if (node != null) {
            inorderRec(node.left);
            System.out.print(node.data + " ");
            inorderRec(node.right);
        }
    }

    // Print tree struktural (rotated)
    public void printTree() {
        printRec(root, 0);
    }

    private void printRec(Node node, int level) {
        if (node == null) {
            return;
        }
        printRec(node.right, level + 1);
        System.out.println("    ".repeat(level) + node.data);
        printRec(node.left, level + 1);
    }

    // Main demo
    public static void main(String[] args) {
        Main bst = new Main();
        int[] data = {15, 17, 12, 4, 17, 9, 2, 20, 21, 27};

        // a) Bangun tree
        for (int x : data) {
            bst.insert(x);
        }

        // Output inorder (harus: 2 4 9 12 15 17 17 20 21 27)
        System.out.print("Inorder traversal: ");
        bst.inorder();

        // Print struktur tree
        System.out.println("\nStruktur BST (kanan atas = nilai besar):");
        bst.printTree();
    }
}
