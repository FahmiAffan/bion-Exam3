/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.main;

/**
 *
 * @author fahmi
 */
// Main.java
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        SingleLinkedList list = new SingleLinkedList();
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n===== Menu Single Linked List =====");
            System.out.println("1. Insert banyak angka");
            System.out.println("2. Tampilkan isi list");
            System.out.println("3. Insert angka setelah angka tertentu");
            System.out.println("4. Hapus angka tertentu");
            System.out.println("5. Keluar");
            System.out.print("Pilihan Anda: ");
            choice = scanner.nextInt();
            scanner.nextLine(); // konsumsi newline

            switch (choice) {
                case 1:
                    System.out.println("Masukkan angka (pisahkan dengan spasi):");
                    String input = scanner.nextLine();
                    String[] parts = input.split("\\s+");
                    for (String part : parts) {
                        try {
                            int num = Integer.parseInt(part);
                            list.insertEnd(num);
                        } catch (NumberFormatException e) {
                            System.out.println("Bukan angka valid: " + part);
                        }
                    }
                    break;

                case 2:
                    System.out.println("Isi Linked List:");
                    list.display();
                    break;

                case 3:
                    System.out.print("Masukkan angka yang ingin disisipkan: ");
                    int insertValue = scanner.nextInt();
                    System.out.print("Masukkan angka target (setelah ini akan disisipkan): ");
                    int target = scanner.nextInt();
                    boolean successInsert = list.insertAfter(target, insertValue);
                    if (successInsert)
                        System.out.println("Berhasil menyisipkan " + insertValue + " setelah " + target);
                    else
                        System.out.println("Gagal, angka " + target + " tidak ditemukan.");
                    break;

                case 4:
                    System.out.print("Masukkan angka yang ingin dihapus: ");
                    int deleteValue = scanner.nextInt();
                    boolean successDelete = list.deleteKey(deleteValue);
                    if (successDelete)
                        System.out.println("Berhasil menghapus " + deleteValue);
                    else
                        System.out.println("Gagal, angka " + deleteValue + " tidak ditemukan.");
                    break;

                case 5:
                    System.out.println("Terima kasih! Keluar dari program.");
                    break;

                default:
                    System.out.println("Pilihan tidak valid. Silakan coba lagi.");
            }

        } while (choice != 5);

        scanner.close();
    }
}


