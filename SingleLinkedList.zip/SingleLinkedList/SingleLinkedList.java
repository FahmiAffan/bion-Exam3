/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.main;

/**
 *
 * @author fahmi
 */
// SingleLinkedList.java
public class SingleLinkedList {
    private Node head;

    public void insertEnd(int value) {
        Node newNode = new Node(value);
        if (head == null) {
            head = newNode;
        } else {
            Node cur = head;
            while (cur.next != null) {
                cur = cur.next;
            }
            cur.next = newNode;
        }
    }

    public boolean insertAfter(int key, int value) {
        Node cur = head;
        while (cur != null && cur.data != key) {
            cur = cur.next;
        }
        if (cur == null) return false;
        Node newNode = new Node(value);
        newNode.next = cur.next;
        cur.next = newNode;
        return true;
    }

    public boolean deleteKey(int key) {
        if (head == null) return false;
        if (head.data == key) {
            head = head.next;
            return true;
        }
        Node prev = head;
        Node cur = head.next;
        while (cur != null && cur.data != key) {
            prev = cur;
            cur = cur.next;
        }
        if (cur == null) return false;
        prev.next = cur.next;
        return true;
    }

    public void display() {
        Node cur = head;
        while (cur != null) {
            System.out.print(cur.data);
            if (cur.next != null) System.out.print(" -> ");
            cur = cur.next;
        }
        System.out.println();
    }
}
