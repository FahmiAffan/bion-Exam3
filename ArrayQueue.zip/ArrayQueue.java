// ArrayQueue.java
public class ArrayQueue {
    private int[] data;
    private int front, rear, size, capacity;

    public ArrayQueue(int capacity) {
        this.capacity = capacity;
        data = new int[capacity];
        front = 0;
        rear = -1;
        size = 0;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public boolean isFull() {
        return size == capacity;
    }

    public void enqueue(int x) {
        if (isFull()) throw new IllegalStateException("Queue penuh");
        rear = (rear + 1) % capacity;
        data[rear] = x;
        size++;
    }

    public int dequeue() {
        if (isEmpty()) throw new IllegalStateException("Queue kosong");
        int val = data[front];
        front = (front + 1) % capacity;
        size--;
        return val;
    }

    public void display() {
        System.out.print("Isi Queue: ");
        for (int i = 0; i < size; i++) {
            int idx = (front + i) % capacity;
            System.out.print(data[idx] + " ");
        }
        System.out.println();
    }

    /** Hapus semua elemen == key dengan operasi queue saja */
    public void removeValue(int key) {
        int n = size;
        for (int i = 0; i < n; i++) {
            int x = dequeue();
            if (x != key) {
                enqueue(x);
            }
            // jika x == key, kita skip (tidak enqueue kembali)
        }
    }
}
