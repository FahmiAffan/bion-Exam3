// MainArray.java
public class MainArray {
    public static void main(String[] args) {
        int[] arr = {
            39, 88, 102, 64, 128, 113, 124, 248, 46, 39,
            92, 117, 184, 351, 52, 60, 104, 77, 208, 94
        };

        ArrayQueue q = new ArrayQueue(arr.length);
        for (int x : arr) {
            q.enqueue(x);
        }

        System.out.println("Sebelum menghapus 92:");
        q.display();

        q.removeValue(92);

        System.out.println("Setelah menghapus 92:");
        q.display();
    }
}
